using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace AbizShell
{
    /// <summary>
    /// Главное окно оболочки: встроенный браузер, меню кнопок, календарь, редактор кнопок.
    /// Все кнопки управления — в верхней панели (TopBarWindow). Окно занимает экран под
    /// панелью и НЕ является «поверх всех», поэтому Word/Excel/MAX и проводник открываются поверх него.
    /// </summary>
    public partial class ShellWindow : Window
    {
        public bool IsAdmin { get; set; }
        public string ApiToken { get; set; } = "";
        public string DeviceCode { get; set; } = "";
        public string EmployeeName { get; set; } = "";
        public string DeviceToken { get; set; } = "";
        public bool IsForeignSession { get; set; }
        public string LoginCardNumber { get; set; } = "";
        public string CurrentUserId { get; set; } = "";

        private string AgentToken => string.IsNullOrEmpty(DeviceToken) ? ApiToken : DeviceToken;
        private CardReader? _cardReader;
        private bool _cardBusy;
        private bool _firstPageShown;
        private DispatcherTimer? _splashTimer;

        private RemoteAgent? _remoteAgent;

        public const string HomePage = "https://bizwor.ru/";
        private const string RuDesktopAcceptId = "2364029";

        private DispatcherTimer? _networkTimer, _remoteDesktopTimer, _notificationTimer;
        private DateTime _lastSpacePress = DateTime.MinValue;
        private const int DoublePressInterval = 450;
        private KeyboardHook? _keyboardHook;
        private int _codeClickCount;
        private DateTime _lastCodeClick = DateTime.MinValue;
        private readonly Dictionary<string, string> _notes = new();
        private readonly string _notesPath;
        private string _selectedDate = "";
        private AnodBizClient? _client;
        private List<KioskButton> _buttons = new();
        private readonly List<KioskButtonEditRow> _editorRows = new();
        private TopBarWindow? _topBar;
        private ExplorerWindow? _explorer;
        private bool _allowClose;
        private int _networkFailures;
        private bool _networkOverlayDismissed;

        public ShellWindow()
        {
            InitializeComponent();
            if (!Edition.Kiosk)
            {
                // АБИЗ-Админ — обычное окно Windows: рамка, свернуть/развернуть, панель задач.
                WindowStyle = WindowStyle.SingleBorderWindow;
                ResizeMode = ResizeMode.CanResize;
                ShowInTaskbar = true;
                Width = 1280;
                Height = 820;
                WindowStartupLocation = WindowStartupLocation.CenterScreen;
                Title = Edition.Name;
                if (Content is FrameworkElement root) root.Margin = new Thickness(0, TopBarWindow.BarHeight, 0, 0);
            }
            Loaded += ShellWindow_Loaded;
            Closing += ShellWindow_Closing;
            _notesPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AbizShell", "notes.json");
            LoadNotes();

            _networkTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(15) };
            _networkTimer.Tick += async (s, e) => await CheckNetworkAsync();
            _networkTimer.Start();

            _remoteDesktopTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
            _remoteDesktopTimer.Tick += (s, e) => AutoAcceptRemoteDesktop();
            _remoteDesktopTimer.Start();

            _notificationTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
            _notificationTimer.Tick += async (s, e) => await CheckNotificationsAsync();
            _notificationTimer.Start();
        }

        public CoreWebView2? Browser => MainBrowser.CoreWebView2;

        private void ShellWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_allowClose)
            {
                if (Edition.Kiosk) { e.Cancel = true; return; }
                // АБИЗ-Админ: крестик окна закрывает программу.
                StopEverything();
                Application.Current.Shutdown();
                return;
            }
            StopEverything();
        }

        public void ForceCloseForExit()
        {
            _allowClose = true;
            Close();
        }

        private void StopEverything()
        {
            _networkTimer?.Stop(); _remoteDesktopTimer?.Stop(); _notificationTimer?.Stop();
            if (_remoteAgent != null)
            {
                _ = RemoteControlClient.LogAsync(AgentToken, "signout", "Выход из системы");
                _remoteAgent.Stop();
                _remoteAgent = null;
            }
            _keyboardHook?.Dispose();
            _keyboardHook = null;
            _cardReader?.Dispose();
            _cardReader = null;
            _splashTimer?.Stop();
            if (_explorer != null) { _explorer.ForceClose(); _explorer = null; }
            if (_topBar != null) { _topBar.ForceClose(); _topBar = null; }
        }

        private async void ShellWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _topBar = new TopBarWindow(this, IsAdmin);
            if (Edition.Kiosk)
            {
                TaskbarManager.Hide();
                _topBar.WorkAreaChanged += FitToWorkArea;
                _topBar.Show();
                FitToWorkArea();
            }
            else
            {
                // АБИЗ-Админ: панель — часть обычного окна. Она «приклеена» к верху окна
                // и двигается/сворачивается вместе с ним; рабочий стол Windows не трогаем.
                _topBar.Owner = this;
                _topBar.Show();
                LocationChanged += (s, a) => PlaceAdminTopBar();
                SizeChanged += (s, a) => PlaceAdminTopBar();
                StateChanged += (s, a) => PlaceAdminTopBar();
                PlaceAdminTopBar();
            }

            if (!string.IsNullOrEmpty(DeviceCode))
                DeviceCodeDisplay.Text = "Код ПК: " + DeviceManager.FormatCode(DeviceCode);
            SideCalendar.SelectedDate = DateTime.Today;

            if (!string.IsNullOrEmpty(ApiToken))
                _client = new AnodBizClient(ApiToken);

            // Горячие клавиши работают только когда активна наша программа — иначе
            // Tab и пробел перестали бы работать в Word, Excel и других программах.
            _keyboardHook = new KeyboardHook { BlockSystemKeys = Edition.Kiosk };
            _keyboardHook.KeyHandler = (vkCode, isSysKey) =>
            {
                if (!NativeMethods.IsOwnProcessForeground()) return false;

                if (vkCode == KeyboardHook.VK_ESCAPE)
                {
                    bool handled = false;
                    Dispatcher.Invoke(() =>
                    {
                        if (OverlayGrid.Visibility == Visibility.Visible) { OverlayGrid.Visibility = Visibility.Collapsed; handled = true; }
                        else if (SidePanel.Visibility == Visibility.Visible) { SidePanel.Visibility = Visibility.Collapsed; handled = true; }
                    });
                    return handled;
                }

                if (vkCode == KeyboardHook.VK_TAB && !isSysKey && OverlayGrid.Visibility == Visibility.Visible)
                {
                    Dispatcher.Invoke(ToggleMenu);
                    return true;
                }

                if (vkCode == KeyboardHook.VK_SPACE && !isSysKey)
                {
                    var now = DateTime.Now;
                    if ((now - _lastSpacePress).TotalMilliseconds < DoublePressInterval)
                    {
                        _lastSpacePress = DateTime.MinValue;
                        Dispatcher.Invoke(ToggleMenu);
                        return true;
                    }
                    _lastSpacePress = now;
                }
                return false;
            };

            StartCardReader();

            _splashTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(25) };
            _splashTimer.Tick += (s, a) => HideLoadingSplash();
            _splashTimer.Start();

            BuildTilesFromDefaults();
            await InitBrowserAsync();

            _ = CheckNotificationsAsync();
            _ = CheckNetworkAsync();

            StartRemoteAgent();
        }

        /// <summary>В рабочем столе агент сообщает статус "working" (сотрудник в системе) и выполняет
        /// удалённые команды зам. директора. Команда «Выход» возвращает на экран входа.</summary>
        private void StartRemoteAgent()
        {
            if (_remoteAgent != null || string.IsNullOrEmpty(AgentToken)) return;
            _ = RemoteControlClient.LogAsync(AgentToken, "signin",
                $"Вход в систему: {(string.IsNullOrEmpty(EmployeeName) ? (IsAdmin ? "администратор" : "сотрудник") : EmployeeName)}" +
                (IsForeignSession ? " (по карте, сотрудник другого ПК)" : ""));
            _remoteAgent = new RemoteAgent(AgentToken)
            {
                Presence = "working",
                UserName = string.IsNullOrEmpty(EmployeeName) ? (IsAdmin ? "Администратор" : "") : EmployeeName,
                OnReload = () => Dispatcher.Invoke(() => { try { Browser?.Reload(); } catch { } }),
                OnLogout = () => Dispatcher.Invoke(LockScreen),
                OnRevoked = () => Dispatcher.Invoke(LockScreen),
                // Сотрудник работает — не перебиваем: показываем уведомление, установка при выходе на экран входа.
                OnUpdateReady = () => ShowNotification("\U0001F504", "Доступно обновление АБИЗ " + Updater.StagedVersion,
                    "Установится автоматически при выходе на экран входа (кнопка 🔒)."),
                // Зам нажал «Обновить программу» — ставим сразу, программа перезапустится за ~10 секунд.
                OnForceUpdate = () =>
                {
                    ShowNotification("\U0001F504", "Обновление АБИЗ " + Updater.StagedVersion, "Программа перезапустится через 5 секунд.");
                    var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
                    t.Tick += (s2, e2) =>
                    {
                        t.Stop();
                        if (!Updater.ApplyAndRestart()) return;
                        TaskbarManager.Restore();
                        ForceCloseForExit();
                        Application.Current.Shutdown();
                    };
                    t.Start();
                },
            };
            _remoteAgent.Start();
        }

        /// <summary>АБИЗ-Админ: ставит верхнюю панель поверх верхней части окна (над браузером).</summary>
        private void PlaceAdminTopBar()
        {
            if (_topBar == null || Edition.Kiosk || Content is not FrameworkElement root) return;
            if (WindowState == WindowState.Minimized) return;
            try
            {
                var src = PresentationSource.FromVisual(root);
                if (src?.CompositionTarget == null) return;
                var topLeft = src.CompositionTarget.TransformFromDevice.Transform(root.PointToScreen(new Point(0, 0)));
                _topBar.PlaceInside(topLeft.X, topLeft.Y - TopBarWindow.BarHeight, root.ActualWidth);
            }
            catch { }
        }

        /// <summary>Окно занимает всю рабочую область — под верхней панелью.</summary>
        public void FitToWorkArea()
        {
            if (!Edition.Kiosk) return;
            // Ровно под панелью, до низа экрана — не зависит от того, что Windows считает рабочей областью.
            WindowState = WindowState.Normal;
            Left = 0;
            Top = TopBarWindow.BarHeight;
            Width = SystemParameters.PrimaryScreenWidth;
            Height = SystemParameters.PrimaryScreenHeight - TopBarWindow.BarHeight;
        }

        // --- Браузер ---

        private async Task InitBrowserAsync()
        {
            try
            {
                string dataDir = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "AbizShell", "WebView2");
                Directory.CreateDirectory(dataDir);

                var options = new CoreWebView2EnvironmentOptions { AreBrowserExtensionsEnabled = true };
                var env = await CoreWebView2Environment.CreateAsync(null, dataDir, options);
                await MainBrowser.EnsureCoreWebView2Async(env);
            }
            catch (WebView2RuntimeNotFoundException)
            {
                HideLoadingSplash();
                MessageBox.Show(this,
                    "На компьютере не установлен компонент Microsoft Edge WebView2 — без него браузер не работает.\n\n" +
                    "Переустановите АБИЗ из полного установщика.",
                    "АБИЗ — браузер", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            catch (Exception ex)
            {
                HideLoadingSplash();
                MessageBox.Show(this, "Не удалось запустить встроенный браузер:\n" + ex.Message,
                    "АБИЗ — браузер", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var core = MainBrowser.CoreWebView2;
            core.Settings.AreDefaultContextMenusEnabled = true;
            core.Settings.AreDevToolsEnabled = IsAdmin;
            core.Settings.IsZoomControlEnabled = true;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.AreBrowserAcceleratorKeysEnabled = true;
            // Сайт узнаёт программу по этой метке и включает свой быстрый плеер камер.
            core.Settings.UserAgent = core.Settings.UserAgent + " ABIZ/" + RemoteControlClient.AppVersion;

            // Ссылки «в новом окне» открываем в этом же браузере, а не в отдельном окне.
            core.NewWindowRequested += (s, a) =>
            {
                a.Handled = true;
                try { core.Navigate(a.Uri); } catch { }
            };

            // Камеры показывает сам сайт (свой декодер H.265 в браузере) — быстро и без лишних окон.
            core.SourceChanged += (s, a) => Dispatcher.BeginInvoke(new Action(() =>
            {
                if (IsChatOpen()) _ = RemoteControlClient.MarkChatReadAsync(ApiToken);
                if (!_firstPageShown)
                {
                    string src = Browser?.Source ?? "";
                    if (src.StartsWith("https://bizwor.ru/", StringComparison.OrdinalIgnoreCase)
                        && !src.Contains("/device-login", StringComparison.OrdinalIgnoreCase))
                        HideLoadingSplash();
                }
            }));

            core.NavigationCompleted += (s, a) =>
            {
                bool ok = a.IsSuccess;
                var status = a.WebErrorStatus;
                Dispatcher.BeginInvoke(new Action(() => OnNavigationCompleted(ok, status)));
            };

            await PasswordVault.AttachAsync(core);

            try { await ExtensionsService.InstallAllAsync(core.Profile); } catch { }

            try { await LoadButtonsAsync(); } catch { BuildTilesFromDefaults(); }
            await AutoLoginAndNavigateAsync();
        }

        private void OnNavigationCompleted(bool isSuccess, CoreWebView2WebErrorStatus st)
        {
            if (_firstPageShown) return;
            if (!isSuccess)
            {
                if (st == CoreWebView2WebErrorStatus.OperationCanceled || st == CoreWebView2WebErrorStatus.ConnectionAborted
                    || st == CoreWebView2WebErrorStatus.Unknown)
                    return;
                HideLoadingSplash();
                return;
            }
            string url = Browser?.Source ?? "";
            if (url.Contains("/device-login", StringComparison.OrdinalIgnoreCase) || url == "about:blank")
            {
                var t = new DispatcherTimer { Interval = TimeSpan.FromSeconds(6) };
                t.Tick += (s2, e2) => { t.Stop(); HideLoadingSplash(); };
                t.Start();
                return;
            }
            HideLoadingSplash();
        }

        private void HideLoadingSplash()
        {
            _splashTimer?.Stop();
            if (_firstPageShown) return;
            _firstPageShown = true;
            LoadingSplash.Visibility = Visibility.Collapsed;
        }

        public void NavigateBrowser(string url)
        {
            try
            {
                if (MainBrowser.CoreWebView2 != null)
                    MainBrowser.CoreWebView2.Navigate(url);
                else
                    MainBrowser.Source = new Uri(url);
                Activate();
            }
            catch
            {
                MessageBox.Show(this, "Не удалось открыть: " + url, "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void GoHome() => NavigateBrowser(HomePage);
        public void GoBack() { if (Browser?.CanGoBack == true) Browser.GoBack(); }
        public void GoForward() { if (Browser?.CanGoForward == true) Browser.GoForward(); }
        public void ReloadPage() => Browser?.Reload();
        public void PrintPage() { Activate(); PrintService.PrintSystemDialog(Browser); }
        public string CurrentUrl => Browser?.Source ?? HomePage;

        public void OpenCurrentPageInEdge()
        {
            try { Process.Start(new ProcessStartInfo("msedge.exe", CurrentUrl) { UseShellExecute = true }); }
            catch { MessageBox.Show("Microsoft Edge не найден на этом компьютере.", "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Warning); }
        }

        private async Task AutoLoginAndNavigateAsync()
        {
            if (string.IsNullOrEmpty(ApiToken))
            {
                NavigateBrowser(HomePage);
                return;
            }
            string? code = await AnodBizClient.RequestLoginLinkAsync(ApiToken);
            NavigateBrowser(!string.IsNullOrEmpty(code)
                ? $"https://bizwor.ru/device-login?code={code}"
                : HomePage);
        }

        // --- Меню кнопок ---

        private async Task LoadButtonsAsync()
        {
            _buttons = _client != null ? await KioskButtonsService.LoadAsync(_client) : KioskButtonsService.DefaultButtons();
            BuildTiles();
        }

        private void BuildTilesFromDefaults()
        {
            _buttons = KioskButtonsService.DefaultButtons();
            BuildTiles();
        }

        private static Brush SafeBrush(string color)
        {
            try { return new SolidColorBrush((Color)ColorConverter.ConvertFromString(string.IsNullOrWhiteSpace(color) ? "#125499" : color)); }
            catch { return new SolidColorBrush(Color.FromRgb(0x12, 0x54, 0x99)); }
        }

        private void BuildTiles()
        {
            TilesPanel.Children.Clear();
            foreach (var btn in _buttons)
            {
                var content = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
                content.Children.Add(new TextBlock
                {
                    Text = btn.Action == "app" ? "\uE7F4" : "\uE774",
                    FontFamily = new FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets"),
                    FontSize = 30, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 0, 0, 12),
                });
                content.Children.Add(new TextBlock
                {
                    Text = btn.Text, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center,
                    MaxWidth = 120, HorizontalAlignment = HorizontalAlignment.Center,
                });
                var tile = new Button
                {
                    Style = (Style)FindResource("AppTile"),
                    Content = content,
                    Background = SafeBrush(btn.Color),
                    Tag = btn,
                    ToolTip = btn.Action == "app" ? "Программа: " + btn.Target : "Сайт: " + btn.Target,
                };
                tile.Click += Tile_Click;
                TilesPanel.Children.Add(tile);
            }
        }

        private void Tile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not KioskButton k) return;
            OverlayGrid.Visibility = Visibility.Collapsed;
            if (k.Action == "app")
                AppLauncher.Launch(k.Target, this);
            else
                NavigateBrowser(k.Target);
        }

        public void ToggleMenu()
        {
            Activate();
            EditorOverlay.Visibility = Visibility.Collapsed;
            OverlayGrid.Visibility = OverlayGrid.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void OverlayBackground_MouseDown(object sender, MouseButtonEventArgs e) =>
            OverlayGrid.Visibility = Visibility.Collapsed;

        // --- Проводник ---

        public void OpenExplorer()
        {
            if (_explorer == null || !_explorer.IsLoaded)
            {
                _explorer = new ExplorerWindow { Owner = this };
                _explorer.Show();
            }
            else
            {
                if (_explorer.WindowState == WindowState.Minimized) _explorer.WindowState = WindowState.Normal;
                _explorer.Show();
                _explorer.Activate();
            }
        }

        /// <summary>Загрузить пароли из файла, выгруженного из Яндекс Браузера (или Chrome/Edge).</summary>
        public void ImportPasswords()
        {
            MessageBox.Show(this,
                "Как выгрузить пароли из Яндекс Браузера:\n\n" +
                "1. Откройте Яндекс Браузер → Настройки → Пароли и карты (или browser://passwords).\n" +
                "2. Нажмите ⋯ (три точки) → «Экспортировать пароли» → сохраните файл .csv.\n" +
                "3. Выберите этот файл в следующем окне.\n\n" +
                "Пароли сохранятся на этом компьютере в зашифрованном виде и будут сами вставляться на сайтах.\n" +
                "Файл .csv после загрузки лучше удалить — в нём пароли открытым текстом.",
                "АБИЗ — пароли", MessageBoxButton.OK, MessageBoxImage.Information);
            var dlg = new OpenFileDialog { Filter = "Файл паролей (*.csv)|*.csv|Все файлы|*.*", Title = "Файл паролей из Яндекс Браузера" };
            if (dlg.ShowDialog(this) != true) return;
            try
            {
                var (added, updated) = PasswordVault.ImportCsv(dlg.FileName);
                _ = RemoteControlClient.LogAsync(AgentToken, "note", $"Загружены пароли сайтов: новых {added}, обновлено {updated}");
                var del = MessageBox.Show(this,
                    $"Готово. Новых паролей: {added}, обновлено: {updated}.\nВсего на этом ПК: {PasswordVault.All().Count}.\n\nУдалить исходный файл .csv (рекомендуется)?",
                    "АБИЗ — пароли", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (del == MessageBoxResult.Yes) { try { File.Delete(dlg.FileName); } catch { } }
                Browser?.Reload();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось загрузить пароли: " + ex.Message, "АБИЗ — пароли", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void ClearPasswords()
        {
            if (MessageBox.Show(this, "Удалить все сохранённые пароли сайтов с этого компьютера?", "АБИЗ — пароли",
                    MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            PasswordVault.Clear();
        }

        public void OpenWindowsExplorer()
        {
            try { Process.Start(new ProcessStartInfo("explorer.exe") { UseShellExecute = true }); } catch { }
        }

        /// <summary>Раздел «Камеры»: открываем страницу камер сайта во встроенном браузере (уже со входом).</summary>
        public void OpenCamerasSection()
        {
            string cur = Browser?.Source ?? "";
            if (cur.StartsWith("https://bizwor.ru/", StringComparison.OrdinalIgnoreCase) && !cur.Contains("/login"))
                NavigateBrowser("https://bizwor.ru/cameras");
            else
                _ = OpenSitePageLoggedInAsync("/cameras");
        }

        private async Task OpenSitePageLoggedInAsync(string path)
        {
            string? code = string.IsNullOrEmpty(ApiToken) ? null : await AnodBizClient.RequestLoginLinkAsync(ApiToken);
            NavigateBrowser(!string.IsNullOrEmpty(code)
                ? $"https://bizwor.ru/device-login?code={code}&next={Uri.EscapeDataString(path)}"
                : "https://bizwor.ru" + path);
        }

        /// <summary>Загрузить пароли из файла, выгруженного из Яндекс Браузера (или Chrome/Edge).</summary>
        // --- Удалённый доступ RuDesktop ---

        private void AutoAcceptRemoteDesktop()
        {
            try
            {
                foreach (var proc in Process.GetProcessesByName("RuDesktop"))
                {
                    try
                    {
                        string title = proc.MainWindowTitle;
                        if (string.IsNullOrEmpty(title)) continue;
                        if (title.Contains(RuDesktopAcceptId) || title.Contains("вход", StringComparison.OrdinalIgnoreCase))
                        {
                            NativeMethods.PostMessage(proc.MainWindowHandle, 0x0100, (IntPtr)0x0D, IntPtr.Zero);
                            NativeMethods.PostMessage(proc.MainWindowHandle, 0x0101, (IntPtr)0x0D, IntPtr.Zero);
                        }
                    }
                    catch { }
                    finally { proc.Dispose(); }
                }
            }
            catch { }
        }

        // --- Сеть ---

        private async Task CheckNetworkAsync()
        {
            bool online = await AnodBizClient.CheckNetworkAsync();
            _networkFailures = online ? 0 : _networkFailures + 1;
            bool showOffline = _networkFailures >= 2;
            if (online) _networkOverlayDismissed = false;
            ShellNetworkOverlay.Visibility = showOffline && !_networkOverlayDismissed && _firstPageShown ? Visibility.Visible : Visibility.Collapsed;
            _topBar?.SetOnline(online);
        }

        private async void ShellRetryNetwork_Click(object sender, RoutedEventArgs e)
        {
            _networkFailures = 1;
            await CheckNetworkAsync();
            if (ShellNetworkOverlay.Visibility == Visibility.Collapsed) ReloadPage();
        }

        private void HideNetworkOverlay_Click(object sender, RoutedEventArgs e)
        {
            _networkOverlayDismissed = true;
            ShellNetworkOverlay.Visibility = Visibility.Collapsed;
        }

        // --- Блокировка, выключение, выход ---

        public void LockScreen() => LockScreenWithCard(null);

        public void LockScreenWithCard(string? pendingCard)
        {
            _allowClose = true;
            _cardReader?.Dispose();
            _cardReader = null;
            new MainWindow { PendingCard = pendingCard }.Show();
            Close();
        }

        // --- Карта доступа ---

        private void StartCardReader()
        {
            if (_cardReader != null) return;
            try
            {
                _cardReader = new CardReader(Dispatcher) { OnlyWhenOwnProcessForeground = !Edition.Kiosk };
                _cardReader.CardRead += raw => _ = OnCardReadAsync(raw);
            }
            catch
            {
                _cardReader = null;
            }
        }

        /// <summary>Курсор стоит в поле карты на сайте (подтверждение записи карты СКУД, мастер-карта) —
        /// номер уходит в это поле, а не на вход/выход из программы.</summary>
        private async Task<bool> IsCardFieldFocusedAsync()
        {
            try
            {
                var core = MainBrowser.CoreWebView2;
                if (core == null) return false;
                var r = await core.ExecuteScriptAsync(
                    "(function(){var a=document.activeElement;return !!(a&&a.closest&&a.closest('[data-abiz-card]'));})()");
                return r == "true";
            }
            catch { return false; }
        }

        private async Task OnCardReadAsync(string raw)
        {
            if (_cardBusy || _allowClose) return;
            if (await IsCardFieldFocusedAsync()) return;
            string deviceToken = AgentToken;
            if (string.IsNullOrEmpty(deviceToken))
            {
                ShowNotification("\U0001F4B3", "Карта доступа", "ПК не привязан — вход по карте недоступен");
                return;
            }
            _cardBusy = true;
            try
            {
                var r = await AnodBizClient.DeviceCardSignInAsync(deviceToken, raw);
                if (_allowClose) return;
                switch (r.Result)
                {
                    case AnodBizClient.CardSignInResult.Ok:
                        bool sameUser;
                        if (IsAdmin) sameUser = false;
                        else if (IsForeignSession)
                            sameUser = r.Foreign && ((!string.IsNullOrEmpty(CurrentUserId) && r.UserId == CurrentUserId)
                                                     || (!string.IsNullOrEmpty(r.ForeignToken) && r.ForeignToken == ApiToken));
                        else sameUser = !r.Foreign;

                        if (sameUser || (!string.IsNullOrEmpty(LoginCardNumber) && r.CardNumber == LoginCardNumber))
                        {
                            _ = RemoteControlClient.LogAsync(AgentToken, "note", "Выход по карте " + r.CardNumber);
                            LockScreen();
                        }
                        else
                        {
                            _ = RemoteControlClient.LogAsync(AgentToken, "note", "Смена пользователя по карте: " + r.FullName);
                            LockScreenWithCard(raw);
                        }
                        break;
                    case AnodBizClient.CardSignInResult.DeviceRevoked:
                        LockScreen();
                        break;
                    case AnodBizClient.CardSignInResult.UnknownCard:
                        ShowNotification("\U0001F4B3", "Карта не зарегистрирована",
                            string.IsNullOrEmpty(r.CardNumber) ? "Обратитесь к руководителю" : "Номер " + r.CardNumber + ". Обратитесь к руководителю");
                        break;
                    case AnodBizClient.CardSignInResult.NoOwnPc:
                        ShowNotification("\U0001F4B3", "Карта доступа",
                            string.IsNullOrEmpty(r.Error) ? "У сотрудника нет зарегистрированного ПК" : r.Error);
                        break;
                    case AnodBizClient.CardSignInResult.NoNetwork:
                        ShowNotification("\U0001F4B3", "Карта доступа", "Нет связи с сервером — приложите карту ещё раз");
                        break;
                    default:
                        ShowNotification("\U0001F4B3", "Карта доступа", string.IsNullOrEmpty(r.Error) ? "Не удалось проверить карту" : r.Error);
                        break;
                }
            }
            catch { }
            finally
            {
                _cardBusy = false;
            }
        }

        public void ShutdownPc()
        {
            if (MessageBox.Show("Выключить компьютер?", "АБИЗ", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;
            StopEverything();
            try { Process.Start(new ProcessStartInfo("shutdown", "/s /t 0") { CreateNoWindow = true, UseShellExecute = false }); } catch { }
        }

        public void ExitToWindows()
        {
            string q = Edition.Kiosk ? "Закрыть АБИЗ и выйти в обычный Windows?" : "Закрыть АБИЗ-Админ?";
            if (MessageBox.Show(q, Edition.Name, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;
            _allowClose = true;
            StopEverything();
            TaskbarManager.Restore();
            Application.Current.Shutdown();
        }

        // --- Календарь и заметки ---

        public void ToggleCalendar()
        {
            Activate();
            SidePanel.Visibility = SidePanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void CloseSidePanel_Click(object sender, RoutedEventArgs e) => SidePanel.Visibility = Visibility.Collapsed;

        private void Calendar_SelectedDatesChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!SideCalendar.SelectedDate.HasValue) return;
            _selectedDate = SideCalendar.SelectedDate.Value.ToString("yyyy-MM-dd");
            SelectedDateLabel.Text = SideCalendar.SelectedDate.Value.ToString("d MMMM yyyy", new CultureInfo("ru-RU"));
            NotesBox.Text = _notes.TryGetValue(_selectedDate, out var note) ? note : "";
        }

        private void NotesBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(_selectedDate)) return;
            if (string.IsNullOrWhiteSpace(NotesBox.Text)) _notes.Remove(_selectedDate);
            else _notes[_selectedDate] = NotesBox.Text;
            SaveNotes();
        }

        private void LoadNotes()
        {
            try
            {
                if (!File.Exists(_notesPath)) return;
                var data = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(_notesPath));
                if (data == null) return;
                foreach (var kv in data) _notes[kv.Key] = kv.Value;
            }
            catch { }
        }

        private void SaveNotes()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_notesPath)!);
                File.WriteAllText(_notesPath, JsonSerializer.Serialize(_notes));
            }
            catch { }
        }

        private void QuickAction_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            string url = (btn.Tag?.ToString() ?? "") switch
            {
                "schedule" => "https://bizwor.ru/schedule",
                "salary" => "https://bizwor.ru/salary",
                "collection" => "https://bizwor.ru/collection",
                "documents" => "https://bizwor.ru/documents",
                "chat" => "https://bizwor.ru/chat",
                _ => HomePage,
            };
            NavigateBrowser(url);
            SidePanel.Visibility = Visibility.Collapsed;
        }

        // --- Уведомления ---

        // Чтобы одно и то же сообщение не всплывало каждые 2 минуты — помним, о чём уже сказали.
        private string _lastChatNotified = "";
        private bool _collectionNotified;

        private async Task CheckNotificationsAsync()
        {
            if (_client == null) return;
            try
            {
                // Непрочитанное считает сервер для этого сотрудника: сообщения, которые он уже
                // открыл в чате (на сайте или в программе), больше не всплывают. Каждое — один раз.
                var (count, lastId, sender, text) = await RemoteControlClient.ChatUnreadAsync(ApiToken);
                if (count > 0 && lastId != _lastChatNotified && !IsChatOpen())
                {
                    _lastChatNotified = lastId;
                    if (text.Length > 120) text = text.Substring(0, 120) + "…";
                    ShowNotification("\U0001F4AC",
                        count == 1 ? (string.IsNullOrEmpty(sender) ? "Новое сообщение" : "Сообщение от " + sender) : $"Новых сообщений: {count}",
                        string.IsNullOrEmpty(text) ? "Откройте рабочий чат" : text);
                    return;
                }

                // Незакрытая инкассация — напоминаем один раз, пока не закроют.
                var collResult = await _client.QueryAsync(new
                {
                    table = "collection_data",
                    op = "select",
                    filters = new[] { new { col = "status", op = "eq", value = "pending" } },
                    limit = 1,
                });
                if (HasRows(collResult))
                {
                    if (!_collectionNotified)
                    {
                        _collectionNotified = true;
                        ShowNotification("\U0001F4B0", "Инкассация", "Есть незакрытые смены инкассации");
                    }
                }
                else
                {
                    _collectionNotified = false;
                }
            }
            catch { }
        }

        private bool IsChatOpen()
        {
            var url = Browser?.Source ?? "";
            return url.Contains("/chat", StringComparison.OrdinalIgnoreCase);
        }

        private static bool HasRows(JsonElement result) =>
            result.ValueKind == JsonValueKind.Object &&
            result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array && data.GetArrayLength() > 0;

        private static JsonElement? FirstRow(JsonElement result)
        {
            if (result.ValueKind == JsonValueKind.Object && result.TryGetProperty("data", out var data)
                && data.ValueKind == JsonValueKind.Array && data.GetArrayLength() > 0)
                return data[0];
            return null;
        }

        private static string GetStr(JsonElement row, string name) =>
            row.ValueKind == JsonValueKind.Object && row.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String
                ? p.GetString() ?? "" : "";

        private void ShowNotification(string icon, string title, string message)
        {
            NotificationIcon.Text = icon;
            NotificationTitle.Text = title;
            NotificationMessage.Text = message;
            NotificationPanel.Visibility = Visibility.Visible;

            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(8) };
            timer.Tick += (s, e) => { timer.Stop(); NotificationPanel.Visibility = Visibility.Collapsed; };
            timer.Start();
        }

        private void CloseNotification_Click(object sender, RoutedEventArgs e) => NotificationPanel.Visibility = Visibility.Collapsed;

        // --- Меню администратора ---

        public void ShowAdminMenu(UIElement target)
        {
            var menu = new ContextMenu { PlacementTarget = target, Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom };

            void Add(string header, Action action)
            {
                var item = new MenuItem { Header = header };
                item.Click += (s, a) => action();
                menu.Items.Add(item);
            }

            Add("Пароли сайтов: загрузить из Яндекс Браузера", ImportPasswords);
            Add("Пароли сайтов: удалить все с этого ПК", ClearPasswords);
            Add("Изменить кнопки меню", OpenEditor);
            Add("Обновить кнопки с сервера", async () => { try { await LoadButtonsAsync(); } catch { } });
            Add("Поиск сотрудников", async () => await SearchEmployeeAsync());
            Add("Список принтеров", ShowPrinters);
            Add("Проводник Windows", OpenWindowsExplorer);
            Add("Диспетчер задач", () => AppLauncher.Launch("taskmgr.exe", this));
            menu.Items.Add(new Separator());
            Add(Edition.Kiosk ? "Выйти в Windows" : "Закрыть программу", ExitToWindows);
            menu.IsOpen = true;
        }

        private void ShowPrinters()
        {
            var printers = PrintService.GetInstalledPrinters();
            string text = printers.Count > 0 ? string.Join("\n", printers) : "Принтеры не найдены";
            MessageBox.Show(this, text, "Установленные принтеры", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private async Task SearchEmployeeAsync()
        {
            if (_client == null)
            {
                MessageBox.Show(this, "Нет связи с сервером (устройство не привязано).", "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string? query = InputDialog.Show("Поиск сотрудника", "Введите ФИО или часть имени:", "Найти");
            if (string.IsNullOrWhiteSpace(query)) return;

            try
            {
                var result = await _client.SearchEmployeesAsync(query);
                string info = "Ничего не найдено";
                if (result.ValueKind == JsonValueKind.Object && result.TryGetProperty("data", out var data) && data.ValueKind == JsonValueKind.Array)
                {
                    var lines = new List<string>();
                    foreach (var item in data.EnumerateArray())
                    {
                        string name = Str(item, "full_name", "???");
                        string role = Str(item, "role", "");
                        string dept = Str(item, "department", "");
                        lines.Add($"{name} | {role} | {dept}");
                    }
                    if (lines.Count > 0) info = string.Join("\n", lines);
                }
                MessageBox.Show(this, info, "Результаты поиска", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка: " + ex.Message, "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private static string Str(JsonElement el, string prop, string fallback) =>
            el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? fallback : fallback;

        // --- Код ПК ---

        private async void DeviceCode_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if ((DateTime.Now - _lastCodeClick).TotalSeconds > 2) _codeClickCount = 0;
            _codeClickCount++;
            _lastCodeClick = DateTime.Now;
            if (_codeClickCount < 3) return;
            _codeClickCount = 0;
            if (!IsAdmin)
            {
                MessageBox.Show(this, "Получить новый код может только администратор.", "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                string newCode = await AnodBizClient.RegisterDeviceAsync(Environment.MachineName);
                DeviceManager.SaveDeviceCode(newCode);
                DeviceCode = newCode;
                DeviceCodeDisplay.Text = "Код ПК: " + DeviceManager.FormatCode(newCode);
            }
            catch { }
        }

        // --- Редактор кнопок (только админ) ---

        private void OpenEditor()
        {
            OverlayGrid.Visibility = Visibility.Collapsed;
            _editorRows.Clear();
            foreach (var b in _buttons)
                _editorRows.Add(new KioskButtonEditRow(b));
            RenderEditor();
            EditorOverlay.Visibility = Visibility.Visible;
            Activate();
        }

        private TextBox EditorBox(string text, double width, string tip) => new()
        {
            Text = text, Width = width, Margin = new Thickness(0, 0, 8, 0), FontSize = 13, Padding = new Thickness(8, 5, 8, 5),
            ToolTip = tip, VerticalContentAlignment = VerticalAlignment.Center, Height = 34,
        };

        private Button EditorButton(string text, string tip, Action onClick, Brush? fg = null)
        {
            var b = new Button
            {
                Content = text, MinWidth = 30, Height = 30, Margin = new Thickness(0, 0, 4, 0), Padding = new Thickness(8, 0, 8, 0),
                ToolTip = tip, Cursor = Cursors.Hand,
            };
            b.SetResourceReference(FrameworkElement.StyleProperty, "SecondaryButton");
            b.MinHeight = 0;
            b.Height = 34;
            b.FontSize = 13;
            b.Padding = new Thickness(10, 0, 10, 0);
            if (fg != null) b.Foreground = fg;
            b.Click += (s, e) => onClick();
            return b;
        }

        private void RenderEditor()
        {
            EditorRowsPanel.Children.Clear();
            for (int i = 0; i < _editorRows.Count; i++)
            {
                var row = _editorRows[i];
                var line = new StackPanel { Orientation = Orientation.Horizontal };

                var swatch = new Border { Width = 14, Height = 34, CornerRadius = new CornerRadius(5), Background = SafeBrush(row.Color), Margin = new Thickness(0, 0, 8, 0) };
                var name = EditorBox(row.Text, 150, "Название кнопки");
                name.TextChanged += (s, e) => row.Text = name.Text;
                var target = EditorBox(row.Target, 300, "Сайт (https://...) или путь к программе (.exe)");
                target.TextChanged += (s, e) => row.Target = target.Text;
                var color = EditorBox(row.Color, 84, "Цвет, например #125499");
                color.TextChanged += (s, e) => { row.Color = color.Text; swatch.Background = SafeBrush(color.Text); };

                var type = new ComboBox { Width = 120, Margin = new Thickness(0, 0, 8, 0), Height = 34 };
                type.Items.Add("Сайт");
                type.Items.Add("Программа");
                type.SelectedIndex = row.Action == "app" ? 1 : 0;
                type.SelectionChanged += (s, e) => row.Action = type.SelectedIndex == 1 ? "app" : "web";

                line.Children.Add(swatch);
                line.Children.Add(name);
                line.Children.Add(target);
                line.Children.Add(EditorButton("Обзор", "Выбрать программу (.exe) на компьютере", () =>
                {
                    var dlg = new OpenFileDialog { Filter = "Программы (*.exe;*.lnk)|*.exe;*.lnk|Все файлы|*.*", Title = "Выберите программу" };
                    if (dlg.ShowDialog(this) == true)
                    {
                        target.Text = dlg.FileName;
                        type.SelectedIndex = 1;
                        if (string.IsNullOrWhiteSpace(name.Text) || name.Text == "Новая кнопка")
                            name.Text = Path.GetFileNameWithoutExtension(dlg.FileName);
                    }
                }));
                line.Children.Add(color);
                line.Children.Add(type);
                int index = i;
                line.Children.Add(EditorButton("↑", "Выше", () => MoveRow(index, -1)));
                line.Children.Add(EditorButton("↓", "Ниже", () => MoveRow(index, 1)));
                line.Children.Add(EditorButton("✕", "Удалить", () => { _editorRows.RemoveAt(index); RenderEditor(); }, new SolidColorBrush(Color.FromRgb(0xDC, 0x26, 0x26))));

                EditorRowsPanel.Children.Add(new Border
                {
                    Background = new SolidColorBrush(Color.FromRgb(0xF7, 0xF7, 0xFA)),
                    BorderBrush = new SolidColorBrush(Color.FromRgb(0xE4, 0xE4, 0xEA)), BorderThickness = new Thickness(1),
                    CornerRadius = new CornerRadius(12), Margin = new Thickness(0, 0, 0, 8), Padding = new Thickness(10),
                    Child = line,
                });
            }
        }

        private void MoveRow(int index, int direction)
        {
            int newIndex = index + direction;
            if (newIndex < 0 || newIndex >= _editorRows.Count) return;
            (_editorRows[index], _editorRows[newIndex]) = (_editorRows[newIndex], _editorRows[index]);
            RenderEditor();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            _editorRows.Add(new KioskButtonEditRow(new KioskButton
            {
                Id = Guid.NewGuid().ToString(),
                Text = "Новая кнопка",
                Color = "#0E7490",
                Action = "web",
                Target = "https://",
            }));
            RenderEditor();
        }

        private async void SaveButtons_Click(object sender, RoutedEventArgs e)
        {
            if (_client == null)
            {
                MessageBox.Show(this, "Компьютер не привязан к личному кабинету — сохранить кнопки на сервере нельзя.", "АБИЗ",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var bad = _editorRows.FirstOrDefault(r => string.IsNullOrWhiteSpace(r.Text) || string.IsNullOrWhiteSpace(r.Target) || r.Target == "https://");
            if (bad != null)
            {
                MessageBox.Show(this, "У каждой кнопки должны быть название и адрес сайта или программа.", "АБИЗ",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var list = _editorRows.Select(r => r.ToButton()).ToList();
            bool ok = await KioskButtonsService.SaveAsync(_client, list);
            if (ok)
            {
                _buttons = list;
                BuildTiles();
                EditorOverlay.Visibility = Visibility.Collapsed;
                MessageBox.Show(this, "Кнопки сохранены — появятся на всех компьютерах при следующем входе.", "АБИЗ",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show(this, "Не удалось сохранить — проверьте интернет.", "АБИЗ", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CloseEditor_Click(object sender, RoutedEventArgs e) => EditorOverlay.Visibility = Visibility.Collapsed;
    }

    public class KioskButtonEditRow
    {
        public string Id { get; }
        public string Text { get; set; }
        public string Color { get; set; }
        public string Action { get; set; }
        public string Target { get; set; }

        public KioskButtonEditRow(KioskButton b)
        {
            Id = string.IsNullOrEmpty(b.Id) ? Guid.NewGuid().ToString() : b.Id;
            Text = b.Text;
            Color = b.Color;
            Action = b.Action;
            Target = b.Target;
        }

        public KioskButton ToButton() => new()
        {
            Id = Id,
            Text = Text.Trim(),
            Color = Color.Trim(),
            Action = Action,
            Target = Target.Trim(),
        };
    }
}